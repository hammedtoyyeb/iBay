
// filter script
const filterBtn = document.querySelectorAll('.filterBtn');
const products = document.querySelectorAll('.product');
for (let i = 0; i < filterBtn.length; i++) {
    filterBtn[i].addEventListener("click", (e) => {
        e.preventDefault();        
        const filter = e.target.dataset.filter;        
        products.forEach((product) => {
            if (filter == 'all') {
                product.style.display = 'block';
            } else {             
                    for (let j = 0; j < products.length; j++) {                        
                        if (products[j].classList.contains(filter)) {
                        products[j].style.display = 'block';
                    } else {
                    product.style.display = 'none';
                    }
            }
            
        };
    })
}
)}

// Search filter script
const search = document.getElementById('search');
search.addEventListener('keyup', (e) => {
    e.preventDefault();
    const searchResult = search.value.toLowerCase().trim();
    for (let i = 0; i < products.length; i++) {
        if (searchResult == '') {
            products[i].style.display = 'block'
        } else if (products[i].classList.contains(searchResult)) {
            products[i].style.display = 'block'
        } else {
            products[i].style.display = 'none'
        }
    }
})

// Product Arrays
let productList = [
    {name: 'iPhone 12', tag: 'iPhone12', price: 1844.99, inCart: 0},
    {name: 'iPhone 12 Pro Max', tag: 'iPhone12ProMax', price: 2199.99, inCart: 0},
    {name: 'iPhone 12 Pro', tag: 'iPhone12Pro', price: 1917.99, inCart: 0},
    {name: 'iPhone XS Max Gold', tag: 'iPhoneXSMaxGold', price: 1299.00, inCart: 0},
    {name: 'iPhone 8 Plus Gold', tag: 'iPhone8PlusGold', price: 459.00, inCart: 0},
    {name: 'iPhone 8 Plus SpaceGray', tag: 'iPhone8PlusSpaceGray', price: 469.00, inCart: 0},
    {name: 'iPhone 11 Pro Max', tag: 'iPhone11ProMax', price: 1844.99, inCart: 0},
    {name: 'iPhone 11', tag: 'iPhone11', price: 944.99, inCart: 0},
    {name: 'iPhone XS Max Silver', tag: 'iPhoneXSMaxSilver', price: 649.95, inCart: 0},
    {name: 'iPhone 11 Pro', tag: 'iPhone11Pro', price: 789.95, inCart: 0},
    {name: 'Apple MacBook Air Gold', tag: 'AppleMacBookAirGold', price: 899.92, inCart: 0},
    {name: '2020 Apple MacBook Air', tag: '2020AppleMacBookAir', price: 1189.00, inCart: 0},
    {name: 'New Apple MacBook Pro', tag: 'NewAppleMacBookPro', price: 789.00, inCart: 0},
    {name: 'New Apple MacBook Pro', tag: 'NewAppleMacBookPro', price: 2184.92, inCart: 0},
    {name: 'Apple MNYK2LL', tag: 'AppleMNYK2LL', price: 656.79, inCart: 0},
    {name: 'MacBook Pro', tag: 'MacBookPro', price: 1764.00, inCart: 0},
    {name: 'MacBook Pro MGX72LL', tag: 'MacBookProMGX72LL', price: 649.99, inCart: 0},
    {name: 'Macbook Pro MPXV2LL', tag: 'MacbookProMPXV2LL', price: 1227.95, inCart: 0},
    {name: '2018 MacBook Air', tag: '2018MacBookAir', price: 849.00, inCart: 0},
    {name: 'Apple iMac ME086LL', tag: 'AppleiMacME086LL', price: 944.99, inCart: 0},
    {name: 'iPhone 12 Charger', tag: 'iPhone12Charger', price: 45.78, inCart: 0},
    {name: 'Apple Watch Charger', tag: 'AppleWatchCharger', price: 51.99, inCart: 0},
    {name: 'Apple Watch Series 5 Silver', tag: 'AppleWatchSeries5Silver', price: 311.97, inCart: 0},
    {name: 'Apple Watch Series 5 SpaceGray', tag: 'AppleWatchSeries5SpaceGray', price: 302.97, inCart: 0},
    {name: 'Apple AirPods Pro', tag: 'AppleAirPodsPro', price: 311.00, inCart: 0},
    {name: 'Apple AirPods', tag: 'AppleAirPods', price: 201.00, inCart: 0},
    {name: 'New Apple Watch SE', tag: 'NewAppleWatchSE', price: 269.00, inCart: 0},
    {name: 'MacBook Pro Charger', tag: 'MacBookProCharger', price: 79.99, inCart: 0},
    {name: 'Apple Clear Case', tag: 'AppleClearCase', price: 49.99, inCart: 0},
    {name: 'Apple USB-C Charge Cable', tag: 'AppleUSB-CChargeCable', price: 69.99, inCart: 0}         
  ];

// console.log(productArray);

// Add to cart script
const addToCartBtn = document.querySelectorAll('.btn-sm');
const cartVal = document.querySelector('#cartVal');
for (i = 0; i < addToCartBtn.length; i++) {    
    addToCartBtn[i].addEventListener('click', () => {
        // preventDefault();
        // for (let j = 0; j < productList.length; j++) {
        addToCart(productList[i]); 
        // break;           
    // }
})
}

// Add to cart function
function addToCart (item) {
    console.log('the product clicked is', item);
    let cartReadings = localStorage.getItem('cartVal');
    cartReadings = parseInt(cartReadings);
    if (cartReadings) {
        localStorage.setItem('cartVal', cartReadings + 1);
        cartVal.innerHTML = cartReadings + 1;
    } else {
        localStorage.setItem('cartVal', 1);
        cartVal.innerHTML = 1;
    }
    storeItem (item); 
    // for (let i = 0; i < productList.length; i++) {
         /*(productList[j])*/;       
    // }  
}

// function to store clicked item in the local storage
function storeItem (item) {    
    let cartItem = localStorage.getItem('itemInCart');
    cartItem = JSON.parse(cartItem);
    // for (let i = 0; i < productList.length; i++) {
        // productList.forEach(item).()=> {
        if (cartItem = null) {            
            if (cartItem[item.tag] == undefined) {
                cartItem = {
                    ...cartItem, [productList.tag] : item
                }
                cartItem[productList.tag].inCart += 1;
            }
        } else {
            cartItem = {[productList.tag]: item};
            productList.inCart = 1;
                            
        }
           
    // }
    localStorage.setItem('itemInCart', JSON.stringify(cartItem));
    console.log(cartItem);
    
}

// Auto log cartReadings from the localStorage into the cart
function cartRetrieveVal () {
    let cartReadings = localStorage.getItem('cartVal');
    if (cartReadings) {
        document.querySelector('#cartVal').innerHTML = cartReadings;
    }
}
cartRetrieveVal();
