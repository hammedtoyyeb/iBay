<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="iBay is a major dealer in all kinds of Apple's products till date">
  <meta name="author" content="Toyyeb Olanrewaju Hammed">

  <title>iBay</title>
  <link rel="icon" href="logo/logo.png">

  <!-- fontawesome -->
  <link rel="stylesheet" href="fa/css/all.css">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  
  <!-- Custom styles for this template -->
  <link href="css/shop-homepage.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="logo/logo.png" alt="logo" height="35"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
       
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="prdt.php">Products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">Login</a>
          </li>
        </ul>        
      </div>
    </div>
    <!-- iBay cart -->
    <form action="" method="post">
      <a href="cart.php" style="text-decoration: none;">
        <span class="px-4 py-2 rounded-pill text-dark font-size-16 bg-light">
          <span class="font-size-16 px-0 text-black" id="cartIcon"><i class="fas fa-shopping-cart"></i></span>
          <span id="cartVal"><b>0</b></span>
        </span>
      </a>
    </form>
  </nav>

  <div class="row allProducts" id="allProducts">

    <!-- List of phones -->

    <div class="product col-lg-4 col-md-6 mb-4 phones" id="phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top" src="prdts/prdt1.1.webp" alt="item1"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 12</a>
          </h4>
          <h5>$1,844.99</h5>
          <p class="card-text">Size: 256GB, Color: Blue
            Unlimited plan with 15GB mobile hotspot
            Fastest 4G LTE speeds
            Video streaming at SD quality
            Unlimited calls, texts, and picture messages across the U.S.
            </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top" src="prdts/prdt1.2.webp" alt="item2"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 12 Pro Max</a>
          </h4>
          <h5>$2,199.99</h5>
          <p class="card-text"> Size:128GB, Color: Graphite,
            Unlimited plan with 15GB mobile hotspot
            Fastest 4G LTE speeds
            Video streaming at SD quality
            Unlimited calls, texts, and picture messages across the U.S.                  
            </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top" src="prdts/prdt1.3.webp" alt="item3"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 12 Pro </a>
          </h4>
          <h5>$1,917.99</h5>
          <p class="card-text">Size: 512GB, Color: Pacific Blue                  
            Unlimited plan with 15GB mobile hotspot
            Fastest 4G LTE speeds
            Video streaming at SD quality
            Unlimited calls, texts, and picture messages across the U.S.
            </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-5" src="prdts/prdt1.4.jpg" alt="item4"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone XS Max</a>
          </h4>
          <h5>$1,299.00</h5>
          <p class="card-text">Color: Gold,                  
            Brand:	Apple
            Memory Storage Capacity:	64 GB
            Operating System:	IOS
            Screen Size:	6.5 Inches
            Display Type:	OLED
            Cellular Technology:	4G
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-5" src="prdts/prdt1.5.jpg" alt="item5"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 8 Plus</a>
          </h4>
          <h5>$459.00</h5>
          <p class="card-text">Color: Gold
            Memory Storage Capacity:	256 GB
            Operating System	IOS: 8
            Screen Size:	4.7 Inches
            Display Type:	LCD
            Cellular Technology:	4G
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-5" src="prdts/prdt1.6.webp" alt="item6"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 8 Plus</a>
          </h4>
          <h5>$469.00</h5>
          <p class="card-text">Color: Space Gray 
            Memory Storage Capacity:	256 GB
            Operating System	IOS: 8
            Screen Size:	4.7 Inches
            Display Type:	LCD
            Cellular Technology:	4G
            </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-5" src="prdts/prdt1.7.jpg" alt="item7"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 11 Pro Max</a>
          </h4>
          <h5>$1,844.99</h5>
          <p class="card-text">Color: Midnight Green
            Memory Storage Capacity:	256 GB
            Screen Size:	6.5 Inches
            Display Type:	OLED
            Manufacturer:	Apple Computer
            Shooting Modes:	Night Mode, Portrait, Slow-Motion, High Dynamic Range
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-5" src="prdts/prdt1.8.jpg" alt="item8"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 11</a>
          </h4>
          <h5>$944.99</h5>
          <p class="card-text">Color: Yellow
            Memory Storage Capacity	256 GB
            Operating System	IOS
            Display Type	LCD
            Cellular Technology	4G
            Manufacturer	Apple Computer                  
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-2 px-3" src="prdts/prdt1.9.jpeg" alt="item9"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone XS Max</a>
          </h4>
          <h5>$649.95</h5>
          <p class="card-text">Color: Silver
            Memory Storage Capacity	64 GB
            Screen Size:	6.5 Inches
            Cellular Technology:	4G
            Manufacturer:	Apple Computer
            Item Weight	0.64 Grams                  
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 phones">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-5" src="prdts/prdt1.10.jpg" alt="item10"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 11 Pro</a>
          </h4>
          <h5>$789.95</h5>
          <p class="card-text">Color: Space Gray
            Memory Storage Capacity:	64 GB
            Style: For Verizon
            Wireless Carrier:	Verizon
            Brand:	Apple
            Manufacturer	Apple Computer
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <!-- List of Laptops -->

    <div class="product col-lg-4 col-md-6 mb-4 laptops" id="laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.1.jpg" alt="item11"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple MacBook Air</a>
          </h4>
          <h5>$899.92</h5>
          <p class="card-text">Color: Gold
            Capacity: 256GB                  
            Brand:	Apple
            Operating System:	Mac OS
            CPU Manufacturer:	Intel
            Screen Size:	13 Inches
            Computer Memory Size: 8 GB                  
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.2.jpg" alt="item12"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">2020 Apple MacBook Air</a>
          </h4>
          <h5>$1,189.00</h5>
          <p class="card-text">Color: Gold
            Capacity: 512GB SSD
            Brand:	Apple
            Operating System:	Mac OS
            CPU Manufacturer:	Apple (Apple M1 Chip)
            Screen Size:	13.3 Inches
            Computer Memory Size:	8 GB                 
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.3.jpg" alt="item13"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">New Apple MacBook Pro</a>
          </h4>
          <h5>$789.00</h5>
          <p class="card-text">Color: Space Gray
            Capacity: 256GB SSD
            Brand:	Apple
            Operating System:	Mac OS
            CPU Manufacturer:	Apple (Apple M1 Chip)
            Screen Size:	13.3 Inches
            Computer Memory Size:	8 GB                 
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>
    
    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.4.jpg" alt="item14"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">New Apple MacBook Pro</a>
          </h4>
          <h5>$2,184.92</h5>
          <p class="card-text">Color: Space Gray
            Capacity: 512GB SSD
            Brand:	Apple
            CPU Model	Core i7-3720QM (2.6GHz Intel Core i7)
            Computer Memory Size	16 GB
            Ram Memory Installed Size:	16 GB
            Screen Size: 16-inch               
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div> 

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.5.jpg" alt="item15"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple MNYK2LL</a>
          </h4>
          <h5>$656.79</h5>
          <p class="card-text">Color: Gold
            Style: 1.2GHz Dual Core M3
            Capacity: 256GB SSD
            Brand:	Apple
            Operating System:	Chrome OS
            CPU Manufacturer:	Intel
            Screen Size:	12 Inches
            Computer Memory Size:	8GB RAM             
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div> 

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.6.jpg" alt="item16"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">MacBook Pro</a>
          </h4>
          <h5>$1,764.00</h5>
          <p class="card-text">Color: Space Gray
            Style:2.0 GHZ 10th Gen Intel Core i5
            Capacity: 1TB
            Brand:	Apple
            Operating System:	Mac OS
            CPU Manufacturer:	Intel
            Screen Size:	13.3 Inches
            Computer Memory Size	16 GB            
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div> 

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.7.jpg" alt="item17"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">MacBook Pro MGX72LL</a>
          </h4>
          <h5>$649.99</h5>
          <p class="card-text">Color: Space Gray
            Capacity: 128 GB
            Brand:	Apple
            Operating System:	Mac OS X
            CPU Manufacturer:	Intel (2.6ghz)
            Screen Size:	13.3 Inches
            Computer Memory Size:	8 GB            
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div> 

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.8.jpg" alt="item18"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Macbook Pro MPXV2LL</a>
          </h4>
          <h5>$1,227.95</h5>
          <p class="card-text">Color: Space Gray
            Capacity: 256GB
            Brand:	Apple
            Operating System:	Mac OS
            CPU Manufacturer:	Intel (3.1GHz dual-core Intel Core i5)
            Screen Size:	13.3 Inches (LED Screen)
            Computer Memory Size: 8 GB            
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div> 

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt2.9.jpg" alt="item19"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">2018 MacBook Air</a>
          </h4>
          <h5>$849.00</h5>
          <p class="card-text">Color: Space Gray
            Capacity: 128GB
            Brand:	Apple
            Operating System:	Mac OS
            CPU Manufacturer:	Intel (Intel Core i5 1.6 GHz)
            Screen Size:	13.3 Inches
            Computer Memory Size: 8 GB           
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 laptops">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-6 px-4"  src="prdts/prdt2.10.jpg" alt="item20"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple iMac ME086LL</a>
          </h4>
          <h5>$944.99</h5>
          <p class="card-text">Color: Space Gray
            Capacity: 1TB Hard Drive
            Brand	Apple
            CPU Model	Core i5
            Computer Memory Size	8 GB
            Ram Memory Installed Size	8 GB
            Graphics Coprocessor	Intel Iris Pro 5200          
        </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <!-- Accessories -->

    <div class="product col-lg-4 col-md-6 mb-4 accessories" id="accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.1.jpg" alt="item21"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">iPhone 12 Charger</a>
          </h4>
          <h5>$45.78</h5>
          <p class="card-text">
            Equipped with a 20W USB-C Power Delivery port to charge iPhone 12/12 Pro/12 Pro Max, MagSafe Duo, iPhone 11/11 Pro/XS/XR/X, iPad Pro, iPad Air, Galaxy S10 / S9 and other Samsung phones and tablets, more up to 3× faster than with an original charger           
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.2.jpg" alt="item22"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple Watch Charger</a>
          </h4>
          <h5>$51.99</h5>
          <p class="card-text">
            MFi Certified Portable Wireless Fast Magnetic Charging Cable Cord Magnetic Charger Compatible with Apple Watch Series 6/5/4/3/2/1/SE (White)
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.3.jpg" alt="item23"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple Watch Series 5</a>
          </h4>
          <h5>$311.97</h5>
          <p class="card-text">Color: Silver Aluminum Case
            Size: 44MM
            Style:White Sport Band
            Supported Application:	GPS
            Brand:	Apple
            Connectivity Technology:	GPS
            Operating System:	WatchOS                  
            Battery Life	2 days
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.4.jpg" alt="item24"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple Watch Series 5</a>
          </h4>
          <h5>$302.97</h5>
          <p class="card-text">Color: Space Gray Aluminum Case
            Size: 44MM
            Style:White Sport Band
            Supported Application:	GPS
            Brand:	Apple
            Connectivity Technology:	GPS
            Operating System:	WatchOS                  
            Battery Life	2 days
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.5.jpg" alt="item25"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple AirPods Pro</a>
          </h4>
          <h5>$311.00</h5>
          <p class="card-text">Color: White
            Connectivity Technology:	Bluetooth, NFC
            Form Factor:	In Ear
            Noise Control:	Active Noise Cancellation
            Sweat and water resistant
            Easy setup for all your Apple devices
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.6.jpg" alt="item26"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple AirPods</a>
          </h4>
          <h5>$201.00</h5>
          <p class="card-text">Color: White
            Connectivity Technology:	Bluetooth, NFC
            Item Dimensions (LxWxH):	3.98 x 3.98 x 1.34 inches
            Noise Control:	Active Noise Cancellation
            Sweat and water resistant
            Contains Wireless Charging Case                  
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.7.jpg" alt="item27"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">New Apple Watch SE</a>
          </h4>
          <h5>$269.00</h5>
          <p class="card-text">Color: Gold Aluminum Case with Pink Sand Sport Band
            Connectivity Technology:	Bluetooth, NFC
            Supported Application:	Fitness Tracker, Voice Assistant, Elevation Tracker, GPS, Heart Rate Monitor
            Human Interface Input:	Touchscreen, Dial
            Sweat and water resistant
            Contains Wireless Charging Case                  
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.8.jpg" alt="item28"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">MacBook Pro Charger</a>
          </h4>
          <h5>$79.99</h5>
          <p class="card-text">
            61W USB C Charger Power Adapter for MacBook Pro 13 Inch 12 Inch, MacBook 13 Inch 12 Inch, MacBook Air 2018, ipad pro, Included USB-C to USB-C Charge Cable (6.6ft/2m)                  
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.9.jpg" alt="item29"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple Clear Case</a>
          </h4>
          <h5>$49.99</h5>
          <p class="card-text"> Color:	Clear
            Material:	Polycarbonate
            Brand:	Apple
            Form Factor:	Basic Case                  
            Compatible Phone Models: iPhone 12 and iPhone 12 Pro
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>

    <div class="product col-lg-4 col-md-6 mb-4 accessories">
      <div class="card h-100">
        <a href="#"><img class="card-img-top img-fluid py-4 px-3"  src="prdts/prdt3.10.jpg" alt="item30"></a>
        <div class="card-body">
          <h4 class="card-title" >
            <a href="#" style="text-decoration: none;">Apple USB-C Charge Cable</a>
          </h4>
          <h5>$69.99</h5>
          <p class="card-text"> Color:	White
            Size:2m
            USB-C connectors on both ends
            Ideal for charging USB-C devices
            Supports USB 2 for syncing and data transfer between USB-C devices
          </p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
        <div class="card-footer">
          <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
        </div>              
      </div>
    </div>   

  </div>

  <!-- Footer -->
  <footer style="background-color: #020f46;; padding-top: 20px; margin-bottom: 0;">  

    <div class="container" id="footer-bottom" style="background-color: #020f46;">
      <p class="m-0 text-center text-white">Copyright &copy; <i>i</i><b>Bay</b> 2021 All Right Reserve</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- font-awesome -->
  <script src="fa/js/all.js"></script>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

  <!-- customize javascript -->
  <script src="script.js"></script>

</body>

</html>