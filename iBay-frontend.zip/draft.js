// Product Arrays
let productArray, id;
for (let i = 0; i < products.length; i++) {
    products.forEach(product => {
       
        localStorage.setItem('eachProduct', JSON.stringify(product));

        let cartData = localStorage.getItem(eachProduct);
        if (eachProduct) {
            cartData = JSON.parse(eachProduct);
            loadProductArray (productArray);
            id = productArray.length;
        } else {
            productArray = [];
            id = 0;
        }
        
    });
}

function loadProductArray (productArray) {
    productArray.forEach(function(item) {
        return (item.name, item.price)

        <div class="product col-lg-4 col-md-6 mb-4 phones" id="phones">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="prdts/prdt1.1.webp" alt="item1"></a>
              <div class="card-body">
                <h4 class="card-title" >
                  <a href="#" style="text-decoration: none;">iPhone 12</a>
                </h4>
                <h5>$1,844.99</h5>
                <p class="card-text">Size: 256GB, Color: Blue
                  Unlimited plan with 15GB mobile hotspot
                  Fastest 4G LTE speeds
                  Video streaming at SD quality
                  Unlimited calls, texts, and picture messages across the U.S.
                  </p>
              </div>
              <button type="button" class="btn btn-primary btn-sm" style="width: max-content; margin: 0 auto 4px; background-color: rgb(201, 59, 15); border: 0;">Add to Cart</button>
              <div class="card-footer">
                <small class="text-muted" style="color: goldenrod !important;">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
              </div>              
            </div>
          </div>
    })
}

let productArray = [
  {name: 'iPhone 12', tag: 'iPhone12', price: 1844.99, inCart: 0},
  {name: 'iPhone 12 Pro Max', tag: 'iPhone12ProMax', price: 2199.99, inCart: 0},
  {name: 'iPhone 12 Pro', tag: 'iPhone12Pro', price: 1917.99, inCart: 0},
  {name: 'iPhone XS Max Gold', tag: 'iPhoneXSMaxGold', price: 1299.00, inCart: 0},
  {name: 'iPhone 8 Plus Gold', tag: 'iPhone8PlusGold', price: 459.00, inCart: 0},
  {name: 'iPhone 8 Plus SpaceGray', tag: 'iPhone8PlusSpaceGray', price: 469.00, inCart: 0},
  {name: 'iPhone 11 Pro Max', tag: 'iPhone11ProMax', price: 1844.99, inCart: 0},
  {name: 'iPhone 11', tag: 'iPhone11', price: 944.99, inCart: 0},
  {name: 'iPhone XS Max Silver', tag: 'iPhoneXSMaxSilver', price: 649.95, inCart: 0},
  {name: 'iPhone 11 Pro', tag: 'iPhone11Pro', price: 789.95, inCart: 0},
  {name: 'Apple MacBook Air Gold', tag: 'AppleMacBookAirGold', price: 899.92, inCart: 0},
  {name: '2020 Apple MacBook Air', tag: '2020AppleMacBookAir', price: 1189.00, inCart: 0},
  {name: 'New Apple MacBook Pro', tag: 'NewAppleMacBookPro', price: 789.00, inCart: 0},
  {name: 'New Apple MacBook Pro', tag: 'NewAppleMacBookPro', price: 2184.92, inCart: 0},
  {name: 'Apple MNYK2LL', tag: 'AppleMNYK2LL', price: 656.79, inCart: 0},
  {name: 'MacBook Pro', tag: 'MacBookPro', price: 1764.00, inCart: 0},
  {name: 'MacBook Pro MGX72LL', tag: 'MacBookProMGX72LL', price: 649.99, inCart: 0},
  {name: 'Macbook Pro MPXV2LL', tag: 'MacbookProMPXV2LL', price: 1227.95, inCart: 0},
  {name: '2018 MacBook Air', tag: '2018MacBookAir', price: 849.00, inCart: 0},
  {name: 'Apple iMac ME086LL', tag: 'AppleiMacME086LL', price: 944.99, inCart: 0},
  {name: 'iPhone 12 Charger', tag: 'iPhone12Charger', price: 45.78, inCart: 0},
  {name: 'Apple Watch Charger', tag: 'AppleWatchCharger', price: 51.99, inCart: 0},
  {name: 'Apple Watch Series 5 Silver', tag: 'AppleWatchSeries5Silver', price: 311.97, inCart: 0},
  {name: 'Apple Watch Series 5 SpaceGray', tag: 'AppleWatchSeries5SpaceGray', price: 302.97, inCart: 0},
  {name: 'Apple AirPods Pro', tag: 'AppleAirPodsPro', price: 311.00, inCart: 0},
  {name: 'Apple AirPods', tag: 'AppleAirPods', price: 201.00, inCart: 0},
  {name: 'New Apple Watch SE', tag: 'NewAppleWatchSE', price: 269.00, inCart: 0},
  {name: 'MacBook Pro Charger', tag: 'MacBookProCharger', price: 79.99, inCart: 0},
  {name: 'Apple Clear Case', tag: 'AppleClearCase', price: 49.99, inCart: 0},
  {name: 'Apple USB-C Charge Cable', tag: 'AppleUSB-CChargeCable', price: 69.99, inCart: 0}         
]